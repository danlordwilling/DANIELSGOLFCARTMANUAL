# 2003 Club Car DS Digital Manual

Custom digital manual for Daniel's 2003 Club Car DS gas golf cart.

GitHub Pages URL:
https://danlordwilling.github.io/DANIELSGOLFCARTMANUAL/

Upload these files to the repository root:
- index.html
- manifest.json
- service-worker.js
- icon.svg

Then GitHub Pages will update automatically.
